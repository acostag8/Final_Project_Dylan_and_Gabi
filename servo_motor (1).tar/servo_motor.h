//=====[#include guards - begin]===============================================

#ifndef _SERVO_MOTOR_H_
#define _SERVO_MOTOR_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================


//=====[Declarations (prototypes) of public functions]=========================
void servoMotorInit();
void servoMotorUpdate();


//=====[#include guards - end]=================================================

#endif // _MOTOR_H_
