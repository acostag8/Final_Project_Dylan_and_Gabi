//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"

#include "siren.h"
//=====[Declaration of private defines]========================================
#define TIME_INCREMENT_MS           10
//=====[Declaration and initialization of public global objects]===============
DigitalInOut sirenPin(PE_10);
//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============
int accumulatedTimeAlarm = 0;
//=====[Declaration and initialization of private global variables]============

//=====[Declarations (prototypes) of private functions]========================

//=====[Implementations of public functions]===================================

void sirenInit() //initalize to off, declare as an open drain
{
   sirenPin.mode(OpenDrain);
   sirenPin.input();
}

void sirenUpdate()  //turns buzzer on, if alarm is on, else buzzer stays off
// The while true part might be messing w everything

{      
    sirenPin.output();
    sirenPin = LOW; 
}


void sirenDeactivate(){
    sirenPin.input();
}

//=====[Implementations of private functions]==================================