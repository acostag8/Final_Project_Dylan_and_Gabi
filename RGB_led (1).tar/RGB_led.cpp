//=====[Libraries]=============================================================
#include "mbed.h"
#include "arm_book_lib.h"
#include "RGB_led.h" 
#include "ldr_sensor.h"

//=====[Declaration of private defines]========================================

//=====[Declaration and initialization of public global objects]===============

//declares each lead of the LED to a pin on the board
DigitalOut redLed(D11);
DigitalOut blueLed(D12);
DigitalOut greenLed (D13);

//=====[Declaration of external public global variables]=======================

extern bool postAlarmState;

//=====[Declaration and initialization of private global variables]============

//=====[Implementations of public functions]===================================

void RGBLedInit()//initialise the LED to be off
{
    redLed = OFF;
    blueLed = OFF;
    greenLed = OFF;
}

void RGBLedStateRead()
{

// Only run this function when the alarm has been deactivated (post alarm)
if (postAlarmState){

//if the function ldrSensorUpdat() returns true, (room is dark), LED is on, 
//else LED is off 
    if ( ldrSensorUpdate() == true ) {
        redLed = ON;  
        blueLed = ON;
        greenLed =ON;
 }
    else {
        redLed = OFF; 
        blueLed=OFF;
        greenLed = OFF;  
        
        }
    }
}
void turnRGBON(){
    redLed = ON;  
    blueLed = ON;
    greenLed =ON;
}

