//=====[Libraries]=============================================================

#include "mbed.h" 
#include "arm_book_lib.h"

#include "user_interface.h"
#include "pc_serial_com.h" 
#include "alarm.h"
#include "date_and_time.h"
#include "alarm_clock_system.h"
#include "display.h"

//=====[Declaration of private defines]========================================

#define DISPLAY_REFRESH_TIME_MS 1000


//=====[Declaration of private data types]=====================================


//=====[Declaration and initialization of public global objects]===============

//=====[Declaration of external public global variables]=======================
extern char alarmTimeArray[8];
extern char dateAndTimeStr[23];
//=====[Declaration and initialization of public global variables]=============


//=====[Declaration and initialization of private global variables]============

//=====[Declarations (prototypes) of private functions]========================

static void userInterfaceDisplayInit();
static void userInterfaceDisplayUpdate();
static void welcomeMessage();
void alarmActivationUpdate();

//=====[Implementations of public functions]===================================

void userInterfaceInit()
{
    userInterfaceDisplayInit();
} 

void userInterfaceUpdate()
{
    userInterfaceDisplayUpdate();
}
//=====[Implementations of private functions]==================================

static void userInterfaceDisplayInit()
{
   displayInit();
   welcomeMessage();
}

static void userInterfaceDisplayUpdate()
{
    static int accumulatedDisplayTime = 0;

    if( accumulatedDisplayTime >=
        DISPLAY_REFRESH_TIME_MS ) {

        accumulatedDisplayTime = 0;

// Display the Time on the LCD and check if the alarm time equals the current time
        displayDateAndTime();
        alarmActivationUpdate();
    }
    else {
        accumulatedDisplayTime = accumulatedDisplayTime + SYSTEM_TIME_INCREMENT_MS;
    }
}

// Upon reset, send a message to the user instructing them how to set up the alarm
static void welcomeMessage(){

    displayCharPositionWrite ( 0,0 );
    displayStringWrite ("Welcome!");
    delay(3000);

    displayCharPositionWrite ( 0,0 );
    displayStringWrite ("Use Serial Mon. ");
    displayCharPositionWrite ( 0,1 );
    displayStringWrite ("For instructions");
    delay(3000);

    displayCharPositionWrite ( 0,1 );
    displayStringWrite ("Alarm: Not set  ");

}

//Activate the alarm when the alarm time is the same as the current time
void alarmActivationUpdate(){

//Turn each space and : in the dateAndTimeRead string to null, so that when 
//we display the time as string, it knows to stop at null if (alarmSet) Set a 
//null character in between the pairs of digits
    alarmTimeArray[2] = 0;
    alarmTimeArray[5] = 0;

    alarmTimeArray[2] = 0;
    alarmTimeArray[5] = 0;

//First compares the hour digits, then the minutes digits, then the seconds digits
    if (
        dateAndTimeStr[11] == alarmTimeArray[0]
        && dateAndTimeStr[12] == alarmTimeArray[1]
        && dateAndTimeStr[14] == alarmTimeArray[3]
        && dateAndTimeStr[15] == alarmTimeArray[4]
        && dateAndTimeStr[17] == alarmTimeArray[6]
        && dateAndTimeStr[18] == alarmTimeArray[7]
    )
    {
//This function is implemented in the alarm.cpp file. Once called, it starts the alarm
        alarmStateRead();
    }
}
