//=====[Libraries]=============================================================

#include "mbed.h"

#include "ldr_sensor.h"


//=====[Declaration of private defines]========================================

#define LDR_NUMBER_OF_AVG_SAMPLES    10
#define LIGHT_ANALOG_LIMIT           0.2
//=====[Declaration of private data types]=====================================

//=====[Declaration and initialization of public global objects]===============

AnalogIn LDR(A2);

//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============

//=====[Declaration and initialization of private global variables]============

static float ldrReadingV = 0.0;
static float ldrReadingsAverage = 0.0;
static float ldrReadingsArray[LDR_NUMBER_OF_AVG_SAMPLES];
static bool wakeUpSensor = false;

//=====[Declarations (prototypes) of private functions]========================


//=====[Implementations of public functions]===================================

void ldrSensorInit()//LDR reads room and takes samples of the readings 
{
    int i;
    
    for( i=0; i<LDR_NUMBER_OF_AVG_SAMPLES ; i++ ) {
        ldrReadingsArray[i] = 0;  }
    }

float ldrSensorReading()//reads the LDR and averages the samples
{
    static int ldrSampleIndex = 0;
    float ldrReadingsSum = 0.0;
    float ldrReadingsAverage = 0.0;

    int i = 0;

    ldrReadingsArray[ldrSampleIndex] = LDR.read();
       ldrSampleIndex++;
    if ( ldrSampleIndex >= LDR_NUMBER_OF_AVG_SAMPLES) {
        ldrSampleIndex = 0;
    }
    
   ldrReadingsSum = 0.0;
    for (i = 0; i < LDR_NUMBER_OF_AVG_SAMPLES; i++) {
        ldrReadingsSum = ldrReadingsSum + ldrReadingsArray[i];
    }
        ldrReadingsAverage = ldrReadingsSum / LDR_NUMBER_OF_AVG_SAMPLES;
        ldrReadingV = ldrReadingsAverage;
        return ldrReadingV;
}

bool ldrSensorUpdate()//compares the average with voltage, if reading is less than or equal to the limit then the   
//function is true, else it is false. The function returns either true or false. 

 {
if  (ldrSensorReading() <= LIGHT_ANALOG_LIMIT){
        wakeUpSensor = true;
    } 
else { 
        wakeUpSensor = false; 
    }

    return wakeUpSensor;
 }