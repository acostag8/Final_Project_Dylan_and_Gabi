//=====[#include guards - begin]===============================================

#ifndef _ALARM_H_
#define _ALARM_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================
//=====[Declarations (prototypes) of public functions]=========================

void alarmInit();
void alarmUpdate();
void alarmStateRead();
void alarmDeactivate();

//=====[#include guards - end]=================================================

#endif // _ALARM_H_