//=====[Libraries]=============================================================

#include "mbed.h" 
#include "arm_book_lib.h"

#include "alarm.h"
#include "siren.h"
#include "servo_motor.h"
#include "RGB_led.h"
#include "ir_sensor.h"



//=====[Declaration of private defines]========================================


//=====[Declaration of private data types]=====================================

//=====[Declaration and initialization of public global objects]===============

//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============
bool postAlarmState;
bool alarmState;
//=====[Declaration and initialization of private global variables]============

//=====[Declarations (prototypes) of private functions]========================


//=====[Implementations of public functions]===================================

//Initializes the inputs, outputs, and variables
void alarmInit()
{
    alarmState = OFF;
    postAlarmState = OFF;
    sirenInit();
    irSensorInit(); 
}

// when alarm is activated, buzzer, light, IR sensor and servo motor are on. 
void alarmUpdate() 
{   
if  (alarmState){  
    turnRGBON();
    sirenUpdate();  
    servoMotorUpdate();
    }
else{

    alarmState = OFF;
    }
}

void alarmStateRead()
{
    alarmState = true;
}

//=====[Implementations of private functions]==================================

//Turns off the alarm components
void alarmDeactivate()
{
    alarmState = OFF;
    postAlarmState = ON;
    sirenDeactivate();
    RGBLedInit();
}

