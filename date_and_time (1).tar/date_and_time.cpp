//=====[Libraries]=============================================================

#include "mbed.h"

#include "date_and_time.h"
#include "display.h"
#include <cstdio>// Keil Studio said to include 

//=====[Declaration of private defines]========================================

//=====[Declaration of private data types]=====================================

//=====[Declaration and initialization of public global objects]===============

//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============

//=====[Declaration and initialization of private global variables]============
char dateAndTimeStr[23];
//=====[Declarations (prototypes) of private functions]========================

//=====[Implementations of public functions]===================================

char* dateAndTimeRead()
{
    time_t epochSeconds;
    epochSeconds = time(NULL);
    return ctime(&epochSeconds);    
}

void dateAndTimeWrite( int year, int month, int day, 
                       int hour, int minute, int second )
{
    struct tm rtcTime;

    rtcTime.tm_year = year - 1900;
    rtcTime.tm_mon  = month - 1;
    rtcTime.tm_mday = day;
    rtcTime.tm_hour = hour;
    rtcTime.tm_min  = minute;
    rtcTime.tm_sec  = second;

    rtcTime.tm_isdst = -1;

    set_time( mktime( &rtcTime ) );
}

// Displays the current time to the LCD, constantly called and updated in the
// alarm clock system updtate loop 
void displayDateAndTime()
{

    sprintf ( dateAndTimeStr, dateAndTimeRead() );
    // Assign each space and : in the dateAndTimeRead string to null, so that  
    // when we display the time as string, it knows to stop at null
    dateAndTimeStr[3] = 0;
    dateAndTimeStr[7] = 0;
    dateAndTimeStr[10] = 0;
    dateAndTimeStr[13] = 0;
    dateAndTimeStr[16] = 0;
    dateAndTimeStr[19] = 0;

if (dateAndTimeStr[0]){
    // display the hour
    displayCharPositionWrite ( 0,0 );
    displayStringWrite (&dateAndTimeStr[11]);

    displayCharPositionWrite ( 2,0 );
    displayStringWrite (":");

    //display the minute
    displayCharPositionWrite ( 3,0 );
    displayStringWrite (&dateAndTimeStr[14]);

    displayCharPositionWrite ( 5,0 );
    displayStringWrite (":");

    //display the seconds
    displayCharPositionWrite ( 6,0 );
    displayStringWrite (&dateAndTimeStr[17]);

    // cancel out the welcome message
    displayCharPositionWrite ( 8,0 );
    displayStringWrite ("        ");

    }
}
//=====[Implementations of private functions]==================================

