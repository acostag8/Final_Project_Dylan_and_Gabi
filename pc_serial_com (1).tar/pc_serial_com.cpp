//=====[Libraries]=============================================================

#include "mbed.h"
#include "arm_book_lib.h"

#include "pc_serial_com.h"
#include "date_and_time.h"
#include "display.h"

//=====[Declaration of private defines]========================================

//=====[Declaration of private data types]=====================================


//=====[Declaration and initialization of public global objects]===============

UnbufferedSerial uartUsb(USBTX, USBRX, 115200);

//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============
char alarmTimeArray[8];

//=====[Declaration and initialization of private global variables]============


//=====[Declarations (prototypes) of private functions]========================


static void pcSerialComCommandUpdate( char receivedChar );
static void availableCommands();
static void commandShowCurrentAlarmState();
static void commandSetDateAndTime();
static void commandShowDateAndTime();
static void commandSetAlarmDateAndTime(); // new function
static void commandShowAlarmDateAndTime(); // new function

//=====[Implementations of public functions]===================================

void pcSerialComInit()
{
    availableCommands();
}

char pcSerialComCharRead()
{
    char receivedChar = '\0';
    if( uartUsb.readable() ) {
        uartUsb.read( &receivedChar, 1 );
    }
    return receivedChar;
}

void pcSerialComStringWrite( const char* str )
{
    uartUsb.write( str, strlen(str) );
}


//=====[Implementations of private functions]==================================

static void pcSerialComStringRead( char* str, int strLength )
{
    int strIndex;
    for ( strIndex = 0; strIndex < strLength; strIndex++) {
        uartUsb.read( &str[strIndex] , 1 );
        uartUsb.write( &str[strIndex] ,1 );
    }
    str[strLength]='\0';
}

void pcSerialComUpdate()
{
    char receivedChar = pcSerialComCharRead();
    if( receivedChar != '\0' ) {
        pcSerialComCommandUpdate( receivedChar );
          
    
    }
}
static void pcSerialComCommandUpdate( char receivedChar )
{
    switch (receivedChar) {
        case '1': commandSetDateAndTime(); break;
        case '2': commandShowDateAndTime(); break;
        case '3': commandSetAlarmDateAndTime(); break;
        case '4': commandShowAlarmDateAndTime(); break;
        default: availableCommands(); break;
    } 
}

static void availableCommands()
{
    pcSerialComStringWrite( "Available commands:\r\n" );
    pcSerialComStringWrite( "Press '1' to set the date and time\r\n" );
    pcSerialComStringWrite( "Press '2' to get the date and time\r\n" );
    pcSerialComStringWrite( "Press '3' to set the alarm date and time\r\n");
    pcSerialComStringWrite( "Press '4' to get the alarm date and time\r\n");
    pcSerialComStringWrite( "\r\n" );
}



static void commandSetDateAndTime()// do this for alarm time 
{
    char year[5] = "";
    char month[3] = "";
    char day[3] = "";
    char hour[3] = "";
    char minute[3] = "";
    char second[3] = "";
    
    pcSerialComStringWrite("\r\nType four digits for the current year (YYYY): ");
    pcSerialComStringRead( year, 4);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the current month (01-12): ");
    pcSerialComStringRead( month, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the current day (01-31): ");
    pcSerialComStringRead( day, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the current hour (00-23): ");
    pcSerialComStringRead( hour, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the current minutes (00-59): ");
    pcSerialComStringRead( minute, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the current seconds (00-59): ");
    pcSerialComStringRead( second, 2);
    pcSerialComStringWrite("\r\n");
    
    pcSerialComStringWrite("Date and time has been set\r\n");

    dateAndTimeWrite( atoi(year), atoi(month), atoi(day), 
        atoi(hour), atoi(minute), atoi(second) );
}
static void commandSetAlarmDateAndTime()
{
    
    char alarmHour[3] = "";
    char alarmMinute[3] = "";
    char alarmSecond[3] = "";
    

    pcSerialComStringWrite("Type two digits for the alarm hour (00-23): ");
    pcSerialComStringRead( alarmHour, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the alarm minutes (00-59): ");
    pcSerialComStringRead( alarmMinute, 2);
    pcSerialComStringWrite("\r\n");

    pcSerialComStringWrite("Type two digits for the alarm seconds (00-59): ");
    pcSerialComStringRead( alarmSecond, 2);
    pcSerialComStringWrite("\r\n");
    
    pcSerialComStringWrite("Alarm date and time has been set\r\n");

// Add the alarm time values into an array that can be referenced later 

    alarmTimeArray[0] = alarmHour[0];
    alarmTimeArray[1] = alarmHour[1];
  
    alarmTimeArray[3] = alarmMinute[0];
    alarmTimeArray[4] = alarmMinute[1];
 
    alarmTimeArray[6] = alarmSecond[0];
    alarmTimeArray[7] = alarmSecond[1];

    displayCharPositionWrite ( 0,1 );
    displayStringWrite ("Alarm: Set      ");
}
static void commandShowDateAndTime()
{
    char str[100] = "";
    sprintf ( str, "Date and Time = %s", dateAndTimeRead() );
    pcSerialComStringWrite( str );
    pcSerialComStringWrite("\r\n");
}

static void commandShowAlarmDateAndTime()//Display the alarm time that has been previously set
{   
    char alarmStr[100] = "";
    pcSerialComStringWrite("\r\n");
    pcSerialComStringWrite("The alarm time is: ");
    // Displays the hour
    sprintf ( alarmStr, &alarmTimeArray[0] );
    pcSerialComStringWrite( alarmStr );
    pcSerialComStringWrite(":");
    // Displays the minute
    sprintf ( alarmStr, &alarmTimeArray[3] );
    pcSerialComStringWrite( alarmStr );
    pcSerialComStringWrite(":");
    // Displays the second
    sprintf ( alarmStr, &alarmTimeArray[6] );
    pcSerialComStringWrite( alarmStr );
    pcSerialComStringWrite("\r\n");
}
